# 🏠 ArchiGen - House Architecture Design System

## 📖 Overview

ArchiGen is a Java-based House Architecture Design application developed using Eclipse IDE. The project provides an interactive platform for designing and visualizing house layouts through a user-friendly interface. It demonstrates Object-Oriented Programming (OOP) principles, software design concepts, and application development skills while simplifying architectural planning and layout creation.

---

## ✨ Features

- 🏠 House layout design and visualization
- 📐 Interactive architectural planning
- 🖥️ User-friendly graphical interface
- 🏗️ Structured and modular design system
- ⚡ Efficient project management
- 🔄 Object-Oriented Programming implementation
- 📋 Organized project workflow

---

## 🛠️ Technologies Used

- Java
- Eclipse IDE
- Java Swing/AWT (if used)
- Object-Oriented Programming (OOP)

---

## 📸 Screenshots

<img width="1917" height="1020" alt="Screenshot 2026-06-18 145015" src="https://github.com/user-attachments/assets/1e7ccf29-2cce-45ce-b5fc-34442db1ed05" />
<img width="1917" height="1020" alt="Screenshot 2026-06-18 145317" src="https://github.com/user-attachments/assets/78df0c51-af77-4ec0-be3a-6ad544827da1" />
<img width="1913" height="1026" alt="Screenshot 2026-06-18 145347" src="https://github.com/user-attachments/assets/c67b2496-e1b4-4b45-acb1-9cc52315d3c9" />
<img width="409" height="776" alt="Screenshot 2026-06-18 145426" src="https://github.com/user-attachments/assets/b08f55a6-e729-41ca-a05e-6d96c68162e9" />

---

## 📂 Project Structure

```text
ArchiGen
│
├── src/
├── screenshots/
├── resources/
├── README.md
└── project files
```

---

## 🚀 How to Run

1. Clone this repository.
2. Open the project in Eclipse IDE.
3. Import the project into your workspace.
4. Run the main Java file.
5. Start designing and visualizing house layouts.

---

## 🎯 Objectives

- Simplify house architecture planning
- Demonstrate Java application development
- Apply Object-Oriented Programming concepts
- Create an interactive design environment
- Develop problem-solving and software design skills

---

## 🔮 Future Enhancements

- 3D house visualization
- Advanced room customization
- Export designs as PDF/Image
- Multiple architectural templates
- Cost estimation module
- Cloud storage integration

---

## 👩‍💻 Author

**Isha Bawa**

B.Tech CSE Student | Java Developer | Data Analytics Enthusiast

---

⭐ If you found this project useful, consider giving it a star!
